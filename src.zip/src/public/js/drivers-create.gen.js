// src/public/js/drivers-create.ts
import { setCurrentNavLocation } from "./module_functions.gen.js";
function handleSubmit(evt) {
  const form = document.getElementById("packingForm");
  const hiddenFld = document.getElementById("itemsJson");
  const tableBody = document.getElementById("itemTable");
  evt.preventDefault();
  const items = [];
  tableBody.querySelectorAll("tr").forEach((tr) => {
    const tVal = tr.querySelector(`input[name^="t_"]`).value.trim();
    if (!tVal) return;
    items.push({
      title: tVal,
      // @ts-expect-error TS(2531): Object is possibly 'null'.
      description: tr.querySelector(`input[name^="d_"]`).value.trim(),
      // @ts-expect-error TS(2531): Object is possibly 'null'.
      maxAssignees: tr.querySelector(`input[name^="m_"]`).value
    });
  });
  hiddenFld.value = JSON.stringify(items);
  form.submit();
}
function initListeners() {
  const form = document.getElementById("packingForm");
  form?.addEventListener("submit", handleSubmit);
}
function init() {
  setCurrentNavLocation();
  initListeners();
}
window.Surveyor.init = init;
export {
  handleSubmit,
  init,
  initListeners
};
//# sourceMappingURL=drivers-create.gen.js.map
