// src/public/js/activity.ts
import {
  getSelectValues,
  post,
  setCurrentNavLocation,
  showInlineAlert,
  startInlineEdit,
  startInlineEditArea
} from "./module_functions.gen.js";
function initAssign() {
  document.addEventListener("click", async (e) => {
    const btn = e.target?.closest("[data-action]");
    if (!btn) return;
    const card = btn.closest(".slot");
    const slotId = card?.dataset.slotid;
    if (!slotId) return;
    const act = btn.dataset.action;
    const role = btn.dataset.role;
    try {
      await post(`/activity/${window.ACT_PLAN_ID}/${act}`, { slotId, role });
      showInlineAlert("success", "Updated");
      setTimeout(() => location.reload(), 120);
    } catch (err) {
      showInlineAlert("error", err.message);
    }
  });
}
function initSelectBox() {
  $(".multiSelect").select2({
    placeholder: "Add Roles",
    width: "100%",
    //@ts-ignore
    selectionCssClass: "text-bg-dark",
    dropdownCssClass: "text-bg-dark"
  });
  document.addEventListener("click", async (e) => {
    const btn = e.target.closest("[data-addRoles]");
    if (!btn) return;
    const div = btn.closest(".role-assignment");
    if (!div) return;
    const sel = div.querySelector("select");
    if (!sel) return;
    const slot = sel.dataset.id;
    const vals = getSelectValues(sel);
    try {
      await post(`/activity/${window.ACT_PLAN_ID}/slot/${slot}/addRole`, { roles: vals });
      showInlineAlert("success", "Updated");
      setTimeout(() => location.reload(), 120);
    } catch (err) {
      showInlineAlert("error", err.message);
    }
  });
}
function initInlineEdit() {
  document.addEventListener("dblclick", (e) => {
    const desc = e.target.closest('[data-edit="planDescription"]');
    if (desc) return startInlineEditArea(desc, `/activity/${window.ACT_PLAN_ID}/description`);
    const card = e.target.closest(".slot");
    if (!card || e.target.closest("button")) return;
    let span = e.target.closest("[data-edit]");
    if (!span && e.target.closest(".badge"))
      span = card.querySelector('[data-edit="maxAssignees"]');
    if (!span && e.target.closest("small"))
      span = card.querySelector('[data-edit="description"]');
    if (!span)
      span = card.querySelector('[data-edit="title"]');
    startInlineEdit(span, `/activity/${window.ACT_PLAN_ID}/slot`);
  });
}
function initDelete() {
  document.addEventListener("click", async (e) => {
    const btn = e.target.closest("[data-delete-slot]");
    if (!btn) return;
    if (!confirm("Delete this slot?")) return;
    const id = btn.dataset.slotid;
    try {
      await post(`/activity/${window.ACT_PLAN_ID}/slot/${id}/delete`, {});
      showInlineAlert("success", "Deleted");
      setTimeout(() => location.reload(), 100);
    } catch (err) {
      showInlineAlert("error", err.message);
    }
  });
}
function initAddSlot() {
  document.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-add-slot]");
    if (!btn) return;
    const dateISO = btn.dataset.date;
    const cell = btn.parentElement;
    btn.remove();
    const wrap = document.createElement("div");
    wrap.className = "d-grid gap-1";
    const title = document.createElement("input");
    title.className = "form-control form-control-sm text-bg-dark";
    title.placeholder = "Title";
    title.required = true;
    const desc = document.createElement("input");
    desc.className = "form-control form-control-sm text-bg-dark";
    desc.placeholder = "Description";
    const max = document.createElement("input");
    max.type = "number";
    max.min = "1";
    max.value = "1";
    max.className = "form-control form-control-sm text-bg-dark";
    const save = document.createElement("button");
    save.className = "btn btn-sm btn-success mt-1";
    save.textContent = "Add";
    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "btn btn-sm btn-outline-secondary mt-1";
    cancel.textContent = "\xD7";
    wrap.append(title, desc, max, save, cancel);
    cell.appendChild(wrap);
    cancel.onclick = () => {
      wrap.remove();
      cell.appendChild(btn);
    };
    save.onclick = async () => {
      try {
        await post(`/activity/${window.ACT_PLAN_ID}/slot/add`, {
          date: dateISO,
          title: title.value.trim(),
          description: desc.value.trim(),
          maxAssignees: max.value
        });
        showInlineAlert("success", "Added");
        setTimeout(() => location.reload(), 100);
      } catch (err) {
        showInlineAlert("error", err.message);
      }
    };
  });
}
function initDnD() {
  let dragCard = null;
  let dragParent = null;
  document.addEventListener("dragstart", (e) => {
    if (e.target.closest("button") || e.target.closest("input")) return;
    const card = e.target.closest(".slot");
    if (!card) return;
    dragCard = card;
    dragParent = card.parentElement;
    e.dataTransfer.setData("text/plain", "");
    e.dataTransfer.effectAllowed = "move";
  });
  document.addEventListener("dragover", (e) => {
    if (!dragCard) return;
    const overCard = e.target.closest(".slot");
    if (!overCard || overCard === dragCard) return;
    if (overCard.parentElement !== dragParent) return;
    e.preventDefault();
    const rect = overCard.getBoundingClientRect();
    dragParent.insertBefore(
      dragCard,
      e.clientY - rect.top > rect.height / 2 ? overCard.nextSibling : overCard
    );
  });
  document.addEventListener("dragend", async () => {
    if (!dragCard) return;
    const order = [...dragParent.querySelectorAll(".slot")].map((el, i) => ({ slotId: el.dataset.slotid, pos: i }));
    try {
      await post(`/activity/${window.ACT_PLAN_ID}/slot/reorder`, { order });
      showInlineAlert("success", "Reordered");
    } catch (err) {
      showInlineAlert("error", err.message);
    }
    dragCard = dragParent = null;
  });
}
function initOwnerFlags() {
  const form = document.getElementById("flagForm");
  if (!form) return;
  form.addEventListener("change", async () => {
    const payload = {
      // @ts-expect-error TS(2531): Object is possibly 'null'.
      allowAdd: document.getElementById("allowAddSwitch").checked,
      // @ts-expect-error TS(2531): Object is possibly 'null'.
      guestManage: document.getElementById("guestManageSwitch").checked
    };
    try {
      await post(`/activity/${window.ACT_PLAN_ID}/settings`, payload);
      showInlineAlert("success", "Settings updated");
      setTimeout(() => location.reload(), 100);
    } catch (err) {
      showInlineAlert("error", err.message);
      setTimeout(() => location.reload(), 800);
    }
  });
}
function initOwnerRemove() {
  document.addEventListener("click", async (e) => {
    const btn = e.target.closest("button[data-owner-remove]");
    if (!btn) return;
    const assignId = btn.dataset.assignid;
    try {
      await post(`/activity/${window.ACT_PLAN_ID}/assignment/${assignId}/delete`, {});
      showInlineAlert("success", "Removed");
      setTimeout(() => location.reload(), 100);
    } catch (err) {
      showInlineAlert("error", err.message);
    }
  });
}
function initDates() {
  document.querySelectorAll("th[data-date]").forEach((th) => {
    const [y, m, day] = th.dataset.date.split("-").map(Number);
    const d = new Date(Date.UTC(y, m - 1, day));
    th.querySelector(".day").textContent = d.toLocaleDateString(void 0, { weekday: "short" });
    th.querySelector(".date").textContent = d.toLocaleDateString();
  });
}
function init() {
  setCurrentNavLocation();
  initDates();
  initSelectBox();
  if (window.ACT_PLAN_ID) {
    initAssign();
    initInlineEdit();
    initDelete();
    initAddSlot();
    initDnD();
    initOwnerFlags();
    initOwnerRemove();
  }
}
window.Surveyor.init = init;
export {
  init,
  initAddSlot,
  initAssign,
  initDates,
  initDelete,
  initDnD,
  initInlineEdit,
  initOwnerFlags,
  initOwnerRemove,
  initSelectBox
};
//# sourceMappingURL=activity.gen.js.map
