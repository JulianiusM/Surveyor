// src/public/js/survey-create.ts
import { setCurrentNavLocation } from "./module_functions.gen.js";
function initButtons() {
  const tableBody = document.getElementById("combinationTable");
  const addBtn = document.getElementById("addCombinationBtn");
  let counter = 0;
  const weekdays = [
    ["Monday", "MON"],
    ["Tuesday", "TUE"],
    ["Wednesday", "WED"],
    ["Thursday", "THU"],
    ["Friday", "FRI"],
    ["Saturday", "SAT"],
    ["Sunday", "SUN"]
  ];
  const weeks = ["1", "2", "3", "4", "LAST"];
  function addCombinationRow(weekday = void 0, week = void 0) {
    const id = counter++;
    const tr = document.createElement("tr");
    tr.id = `row-${id}`;
    const tdDay = document.createElement("td");
    const selDay = document.createElement("select");
    selDay.className = "form-select text-bg-dark";
    selDay.name = `combinations[${id}][weekday]`;
    selDay.required = true;
    weekdays.forEach(([label, val]) => {
      const opt = document.createElement("option");
      opt.value = val;
      opt.textContent = label;
      selDay.appendChild(opt);
    });
    if (weekday) {
      selDay.value = weekday;
    }
    tdDay.appendChild(selDay);
    const tdWeek = document.createElement("td");
    const selWeek = document.createElement("select");
    selWeek.className = "form-select text-bg-dark";
    selWeek.name = `combinations[${id}][week]`;
    selWeek.required = true;
    weeks.forEach((val) => {
      const opt = document.createElement("option");
      opt.value = val;
      opt.textContent = val === "LAST" ? "Last" : val;
      selWeek.appendChild(opt);
    });
    if (week) {
      selWeek.value = week;
    }
    tdWeek.appendChild(selWeek);
    const tdAction = document.createElement("td");
    tdAction.className = "text-center";
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "btn btn-danger btn-sm remove-combination-btn";
    btn.textContent = "Remove";
    tdAction.appendChild(btn);
    tr.appendChild(tdDay);
    tr.appendChild(tdWeek);
    tr.appendChild(tdAction);
    tableBody?.appendChild(tr);
  }
  if (window.PREFILLED_COMBINATIONS) {
    window.PREFILLED_COMBINATIONS.forEach((c) => addCombinationRow(c.weekday, c.nth_week));
  } else {
    addCombinationRow();
  }
  addBtn?.addEventListener("click", (e) => addCombinationRow());
  tableBody?.addEventListener("click", function(e) {
    if (e.target.matches(".remove-combination-btn")) {
      const row = e.target.closest("tr");
      if (row) row.remove();
    }
  });
}
function init() {
  setCurrentNavLocation();
  initButtons();
}
window.Surveyor.init = init;
export {
  init,
  initButtons
};
//# sourceMappingURL=survey-create.gen.js.map
