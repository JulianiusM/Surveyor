// src/public/js/verify_password.ts
import { matchPassword, removeTooltip, setCurrentNavLocation, validate, verifyPassword } from "./module_functions.gen.js";
function init() {
  registerEvents();
  setCurrentNavLocation();
}
function registerEvents() {
  $("#password").on("keyup", function() {
    verifyPassword($("#password"), $("#password-info"));
  }).on("focusin", function() {
    verifyPassword($("#password"), $("#password-info"));
  }).on("focusout", function() {
    removeTooltip($("#password"), $("#password-info"));
  });
  $("#password_repeat").on("keyup", function() {
    matchPassword($("#password"), $("#password_repeat"), $("#password_repeat-info"));
  });
  $("#form").on("submit", function(event) {
    validate(event, $("#password"), $("#password_repeat"), $("#password-info"), $("#password_repeat-info"));
  });
}
window.Surveyor.init = init;
export {
  init,
  registerEvents
};
//# sourceMappingURL=verify_password.gen.js.map
