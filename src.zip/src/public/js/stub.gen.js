// src/public/js/stub.ts
import { setCurrentNavLocation } from "./module_functions.gen.js";
function init() {
  setCurrentNavLocation();
}
window.Surveyor.init = init;
export {
  init
};
//# sourceMappingURL=stub.gen.js.map
