// src/public/js/modules/timezone-select.ts
function initTimezoneSelect(id, opts) {
  const hid = document.getElementById(`${id}`);
  const btn = document.getElementById(`${id}-btn`);
  const btnLbl = document.getElementById(`${id}-btn-label`);
  const guess = document.getElementById(`${id}-guess`);
  const modalEl = document.getElementById(`${id}-modal`);
  const chipsEl = document.getElementById(`${id}-chips`);
  const search = document.getElementById(`${id}-search`);
  const list = document.getElementById(`${id}-list`);
  if (!hid || !btn || !btnLbl || !modalEl || !chipsEl || !search || !list) return;
  const modal = new bootstrap.Modal(modalEl, { focus: true });
  const refDate = opts?.refDateIso ? new Date(opts.refDateIso) : /* @__PURE__ */ new Date();
  function offsetLabel(zone) {
    try {
      const parts = new Intl.DateTimeFormat(void 0, {
        timeZone: zone,
        timeZoneName: "longOffset"
      }).formatToParts(refDate);
      const tzn = (parts.find((p) => p.type === "timeZoneName") || {}).value || "";
      return tzn.replace("GMT", "UTC");
    } catch {
      return "";
    }
  }
  const allZones = (
    // @ts-ignore
    Intl.supportedValuesOf?.("timeZone") || [
      "UTC",
      "Europe/Berlin",
      "Europe/London",
      "America/New_York",
      "America/Chicago",
      "America/Denver",
      "America/Los_Angeles",
      "America/Sao_Paulo",
      "Africa/Johannesburg",
      "Asia/Dubai",
      "Asia/Kolkata",
      "Asia/Singapore",
      "Asia/Tokyo",
      "Australia/Sydney",
      "Pacific/Auckland"
    ]
  );
  const common = Array.isArray(opts?.common) && opts.common.length ? opts.common : [
    "UTC",
    "Europe/Berlin",
    "Europe/London",
    "America/New_York",
    "America/Chicago",
    "America/Denver",
    "America/Los_Angeles",
    "America/Sao_Paulo",
    "Africa/Johannesburg",
    "Asia/Dubai",
    "Asia/Kolkata",
    "Asia/Singapore",
    "Asia/Tokyo",
    "Australia/Sydney",
    "Pacific/Auckland"
  ];
  function label(zone) {
    const off = offsetLabel(zone);
    return off ? `${zone} \u2022 ${off}` : zone;
  }
  function setZone(zone) {
    if (!zone || allZones.indexOf(zone) === -1) return;
    hid.value = zone;
    btnLbl.textContent = label(zone);
    btn.classList.add("btn-outline-success");
    setTimeout(() => btn.classList.remove("btn-outline-success"), 300);
  }
  function renderChips() {
    chipsEl.innerHTML = "";
    common.forEach((z) => {
      if (!allZones.includes(z)) return;
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "btn btn-sm btn-outline-light me-2 mb-2";
      chip.textContent = label(z);
      chip.addEventListener("click", () => {
        setZone(z);
        modal.hide();
      });
      chipsEl.appendChild(chip);
    });
  }
  function renderList(filter) {
    list.innerHTML = "";
    const query = filter.trim().toLowerCase();
    const maxItems = 200;
    let count = 0;
    for (const z of allZones) {
      if (query && !z.toLowerCase().includes(query)) continue;
      const li = document.createElement("li");
      li.className = "list-group-item list-group-item-action py-2 text-bg-dark hover-background";
      li.role = "option";
      li.tabIndex = 0;
      li.dataset.zone = z;
      li.innerHTML = `<div class="d-flex justify-content-between align-items-center hover-background">
           <span class="fw-medium">${z}</span>
           <small>${offsetLabel(z)}</small>
         </div>`;
      li.addEventListener("click", () => {
        setZone(z);
        modal.hide();
      });
      li.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          setZone(z);
          modal.hide();
        }
      });
      list.appendChild(li);
      if (++count >= maxItems) break;
    }
    if (count === 0) {
      const empty = document.createElement("li");
      empty.className = "list-group-item text-bg-dark";
      empty.textContent = "No matches";
      list.appendChild(empty);
    }
  }
  const provided = (opts?.value ?? "").toString();
  let guessZone = "";
  try {
    guessZone = Intl.DateTimeFormat().resolvedOptions().timeZone || "";
  } catch {
  }
  setZone(provided || guessZone || "UTC");
  renderChips();
  renderList("");
  btn.addEventListener("click", () => {
    modal.show();
    setTimeout(() => search.focus(), 200);
  });
  search.addEventListener("input", () => renderList(search.value));
  if (guess) {
    guess.addEventListener("click", () => {
      let z = "";
      try {
        z = Intl.DateTimeFormat().resolvedOptions().timeZone || "";
      } catch {
      }
      setZone(z || "UTC");
    });
  }
  modalEl.addEventListener("hidden.bs.modal", () => {
    search.value = "";
    renderList("");
  });
}
window.Surveyor.initTimezoneSelect = initTimezoneSelect;
export {
  initTimezoneSelect
};
//# sourceMappingURL=timezone-select.gen.js.map
