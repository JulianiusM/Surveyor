// src/public/js/events.ts
import { formatISOInTimeZone, initEntityLists, post, setCurrentNavLocation, showInlineAlert } from "./module_functions.gen.js";
function allergyCheck() {
  const allergyBox = document.getElementById("diet-allergies");
  const notes = document.getElementById("allergyNotes");
  if (allergyBox && notes) {
    let sync2 = function() {
      notes.required = allergyBox.checked;
    };
    var sync = sync2;
    allergyBox.addEventListener("change", sync2);
    sync2();
  }
}
function deadlineUpdater() {
  function fmt(ms) {
    if (ms <= 0) return "closed";
    const s = Math.floor(ms / 1e3);
    const d = Math.floor(s / 86400);
    const h = Math.floor(s % 86400 / 3600);
    const m = Math.floor(s % 3600 / 60);
    return `${d}d ${h}h ${m}m`;
  }
  try {
    const deadlineCnt = document.getElementById("deadlineCountdown");
    const deadline = document.getElementById("deadlineText");
    const deadlineTZ = document.getElementById("deadlineTZ");
    if (!deadline || !deadlineCnt || !deadlineTZ || !deadline.dataset?.date || !deadlineTZ.dataset?.tz) {
      return;
    }
    const date = new Date(deadline.dataset.date);
    deadline.textContent = date.toLocaleString(void 0, {
      dateStyle: "full",
      timeStyle: "full"
    });
    deadlineTZ.textContent = date.toLocaleString(void 0, {
      timeZone: deadlineTZ.dataset?.tz,
      dateStyle: "full",
      timeStyle: "full"
    });
    const t = Date.parse(date.toISOString());
    if (!isNaN(t)) {
      let tick2 = function() {
        const ms = t - Date.now();
        deadlineCnt.textContent = `(${fmt(ms)})`;
      };
      var tick = tick2;
      tick2();
      setInterval(tick2, 6e4);
    }
    const deadlineEdit = document.getElementById("deadlineEdit");
    if (deadlineEdit) {
      const elem = deadlineEdit;
      elem.value = formatISOInTimeZone(date, deadlineTZ.dataset.tz).slice(0, 16);
    }
  } catch (e) {
  }
}
function initRegistration() {
  const form = document.getElementById("registrationForm");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData(form);
      const payload = Object.fromEntries(formData);
      payload.dietary = formData.getAll("dietary");
      await post(`/event/${window.EVENT_ID}/register`, payload);
      showInlineAlert("success", "Registration successful.");
      setTimeout(() => location.reload(), 120);
    } catch (err) {
      showInlineAlert("error", err.message);
    }
  });
}
function initUpdate() {
  const form = document.getElementById("eventUpdateForm");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData(form);
      await post(`/event/${EVENT_ID}/update`, Object.fromEntries(formData));
      showInlineAlert("success", "Updated");
      setTimeout(() => location.reload(), 120);
    } catch (err) {
      showInlineAlert("error", err.message);
    }
  });
}
function initCancelRegistration() {
  const btn = document.getElementById("cancelRegistrationBtn");
  if (!btn) return;
  btn.addEventListener("click", async (e) => {
    if (window.confirm("Are you sure you want to cancel your registration?")) {
      try {
        await post(`/event/${EVENT_ID}/register/delete`);
        showInlineAlert("success", "Registration cancelled!");
        setTimeout(() => location.reload(), 120);
      } catch (err) {
        showInlineAlert("error", err.message);
      }
    }
  });
}
function initDateRange() {
  const start = document.getElementById("startSpan");
  const end = document.getElementById("endSpan");
  if (!start || !end) return;
  const startDate = new Date(Date.parse(start.dataset.start));
  const endDate = new Date(Date.parse(end.dataset.end));
  start.textContent = startDate.toLocaleString(void 0, {
    dateStyle: "full"
  });
  end.textContent = endDate.toLocaleString(void 0, {
    dateStyle: "full"
  });
}
function initRegistrationDateRange() {
  const start = document.getElementById("arrival");
  const end = document.getElementById("departure");
  if (!start || !end) return;
  const startDate = new Date(Date.parse(start.dataset.start));
  const endDate = new Date(Date.parse(end.dataset.end));
  start.textContent = startDate.toLocaleString(void 0, {
    dateStyle: "full"
  });
  end.textContent = endDate.toLocaleString(void 0, {
    dateStyle: "full"
  });
}
function init() {
  setCurrentNavLocation();
  allergyCheck();
  deadlineUpdater();
  initDateRange();
  initRegistrationDateRange();
  initEntityLists();
  if (window.EVENT_ID) {
    initRegistration();
    initCancelRegistration();
    initUpdate();
  }
}
window.Surveyor.init = init;
export {
  allergyCheck,
  deadlineUpdater,
  init,
  initCancelRegistration,
  initDateRange,
  initRegistration,
  initRegistrationDateRange,
  initUpdate
};
//# sourceMappingURL=events.gen.js.map
