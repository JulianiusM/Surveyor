// src/public/js/module_functions.ts
function refreshState(object, validated, validatedClass, invalidatedClass) {
  if (validated && !object.hasClass(validatedClass)) {
    if (object.hasClass(invalidatedClass)) {
      object.removeClass(invalidatedClass);
    }
    object.addClass(validatedClass);
  } else if (!validated && !object.hasClass(invalidatedClass)) {
    if (object.hasClass(validatedClass)) {
      object.removeClass(validatedClass);
    }
    object.addClass(invalidatedClass);
  }
}
function setCurrentNavLocation() {
  let path = window.location.pathname;
  if (path.includes("/settings")) {
    $("#settings").addClass("active");
  } else if (path.includes("/login")) {
    $("#login").addClass("active");
  } else if (path.includes("/register")) {
    $("#register").addClass("active");
  }
}
function verifyPassword(passwordObj, infoObj) {
  let isEightChars = (passwordObj.val()?.length || 0) >= 8;
  let hasLetter = /[a-z,A-Z]/g.test(passwordObj.val() ?? "");
  let hasDigit = /\d/g.test(passwordObj.val() ?? "");
  infoObj.empty();
  infoObj.append(generateTooltip(isEightChars, hasLetter, hasDigit));
  refreshState(passwordObj, isPasswordValid(passwordObj.val()), "is-valid", "is-invalid");
}
function matchPassword(passwordObj, passwordRepeatObj, repeatInfoObj) {
  refreshState(repeatInfoObj, isPasswordRepeatValid(passwordObj.val(), passwordRepeatObj.val()), "invisible", "visible");
  refreshState(passwordRepeatObj, isPasswordRepeatValid(passwordObj.val(), passwordRepeatObj.val()), "is-valid", "is-invalid");
}
function removeTooltip(passwordObj, infoObj) {
  if (isPasswordValid(passwordObj.val() ?? "")) {
    infoObj.empty();
  }
}
function isPasswordValid(password) {
  return !!password && password.length >= 8 && /[a-z,A-Z]/g.test(password) && /\d/g.test(password);
}
function isPasswordRepeatValid(password, passwordRepeat) {
  return password === passwordRepeat;
}
function generateTooltip(hasEight, hasLettr, hasDigit) {
  let tooltipDesc = '<p><b>Password must match the following criteria:</b></p><ul style="list-style-type:none">';
  let tooltipCritOK = '<li style="color:green"><b>\u2713</b>';
  let tooltipCritNO = '<li style="color:red">\u{1F5D9}';
  let tooltipCritEight = "At least <b>eight (8) characters</b>";
  let tooltipCritLettr = "At least <b>one (1) letter</b>";
  let tooltipCritDigit = "At least <b>one (1) digit</b>";
  let tooltipCritClose = "</li>";
  let tooltipClose = "</ul>";
  let tooltipHTML = tooltipDesc;
  if (hasEight) {
    tooltipHTML += tooltipCritOK;
  } else {
    tooltipHTML += tooltipCritNO;
  }
  tooltipHTML += tooltipCritEight + tooltipCritClose;
  if (hasLettr) {
    tooltipHTML += tooltipCritOK;
  } else {
    tooltipHTML += tooltipCritNO;
  }
  tooltipHTML += tooltipCritLettr + tooltipCritClose;
  if (hasDigit) {
    tooltipHTML += tooltipCritOK;
  } else {
    tooltipHTML += tooltipCritNO;
  }
  tooltipHTML += tooltipCritDigit + tooltipCritClose;
  tooltipHTML += tooltipClose;
  return tooltipHTML;
}
function validate(event, passwordObj, passwordRepeatObj, infoObj, passwordRepeatInfoObj) {
  let password = passwordObj.val();
  let passwordRepeat = passwordRepeatObj.val();
  if (!isPasswordValid(password) || !isPasswordRepeatValid(password, passwordRepeat)) {
    event.preventDefault();
    event.stopPropagation();
    alert("Please check that both the password and the password repetition are vaild!");
    verifyPassword(passwordObj, infoObj);
    removeTooltip(passwordObj, infoObj);
    matchPassword(passwordObj, passwordRepeatObj, passwordRepeatInfoObj);
  }
}
function objectToArray(obj) {
  const arr = [];
  const idx = [];
  const keys = Object.keys(obj).sort();
  for (let i = 0; i < keys.length; i++) {
    arr.push(obj[keys[i]]);
    idx.push(keys[i]);
  }
  return [idx, arr];
}
function padNumber(num) {
  return String(num).padStart(2, "0");
}
async function post(url, payload = {}) {
  const res = await fetch("/api" + url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  let data = {};
  try {
    data = await res.json();
  } catch {
  }
  if (!res.ok || data.status === "error") {
    throw new Error(data.message || "Request failed");
  }
  return data;
}
function showInlineAlert(status, message) {
  const alertBox = document.getElementById("liveAlerts");
  if (!alertBox) return;
  const cls = {
    success: "alert-success",
    info: "alert-info",
    error: "alert-danger"
  }[status] || "alert-info";
  alertBox.innerHTML = `
      <div class="alert ${cls} alert-dismissible fade show" role="alert">
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>`;
}
function disableDnD() {
  const draggables = document.getElementsByClassName("draggable");
  for (let elem of draggables) {
    elem.draggable = false;
  }
}
function enableDnD() {
  if (!window.IS_MANAGE) return;
  const draggables = document.getElementsByClassName("draggable");
  for (let elem of draggables) {
    elem.draggable = true;
  }
}
function startInlineEditArea(desc, url) {
  if (!desc || desc.querySelector("textarea")) return;
  const old = desc.innerText.trim();
  const ta = document.createElement("textarea");
  ta.className = "form-control text-bg-dark";
  ta.style.minHeight = "6rem";
  ta.value = old === "double-click to add description" ? "" : old;
  ta.maxLength = 1999;
  desc.innerHTML = "";
  desc.appendChild(ta);
  ta.focus();
  function restore(val) {
    if (val === "double-click to add description") val = "";
    desc.innerHTML = val ? val.replace(/\n/g, "<br>") : '<em class="text-secondary">double-click to add description</em>';
  }
  async function save() {
    const val = ta.value.trim();
    try {
      await post(url, { description: val });
      restore(val);
      showInlineAlert("success", "Description updated");
    } catch (err) {
      restore(old);
      showInlineAlert("error", err.message);
    }
  }
  ta.addEventListener("blur", save);
  ta.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter" && ev.ctrlKey) {
      ev.preventDefault();
      save();
    }
    if (ev.key === "Escape") {
      restore(old);
      ta.blur();
    }
  });
}
function startInlineEdit(elem, baseUrl) {
  if (!elem || elem.querySelector("input")) return;
  disableDnD();
  const field = elem.dataset.edit;
  const id = elem.dataset.id;
  const isTd = elem.nodeName === "TD";
  let old, countTxt;
  if (isTd && field === "maxAssignees") {
    const cntSpan = elem.querySelector("[data-count]");
    countTxt = cntSpan.textContent?.trim();
    old = elem.querySelector("[data-max]")?.textContent?.trim();
  } else {
    old = elem.textContent?.trim();
  }
  const inp = document.createElement("input");
  inp.className = "form-control form-control-sm text-bg-dark draggable-false";
  inp.type = field === "maxAssignees" ? "number" : "text";
  inp.value = old || "";
  elem.textContent = "";
  elem.appendChild(inp);
  inp.focus();
  async function save() {
    const val = inp.value.trim();
    if (val === old) {
      await rollback(old);
      return;
    }
    const url = `${baseUrl}/${id}/${field === "description" ? "description" : "attr"}`;
    try {
      await post(
        url,
        field === "description" ? { description: val } : { field, value: val }
      );
      rollback(val);
      showInlineAlert("success", "Updated");
      if (field === "maxAssignees") {
        setTimeout(() => location.reload(), 100);
      }
    } catch (err) {
      await rollback(old);
      showInlineAlert("error", err.message);
    }
  }
  async function rollback(val) {
    if (isTd && field === "maxAssignees")
      elem.innerHTML = `<span data-count>${countTxt}</span> / <span data-max>${val}</span>`;
    else
      elem.textContent = val || "";
    enableDnD();
  }
  inp.addEventListener("blur", save);
  inp.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter") {
      ev.preventDefault();
      save();
    }
    if (ev.key === "Escape") rollback(old);
  });
}
function getSelectValues(select) {
  let result = [];
  let options = select && select.options;
  for (let i = 0, iLen = options.length; i < iLen; i++) {
    let opt = options[i];
    if (opt.selected) {
      result.push(opt.value || opt.text);
    }
  }
  return result;
}
function formatISOInTimeZone(date, timeZone) {
  const parts = new Intl.DateTimeFormat(void 0, {
    timeZone,
    hour12: false,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  }).formatToParts(date).reduce((acc, p) => {
    acc[p.type] = p.value;
    return acc;
  }, {});
  const tzNamePart = new Intl.DateTimeFormat(void 0, {
    timeZone,
    timeZoneName: "shortOffset"
    // yields "GMT", "GMT+2", "GMT-05:30", etc.
  }).formatToParts(date).find((p) => p.type === "timeZoneName");
  let offset = "+00:00";
  if (tzNamePart && tzNamePart.value.startsWith("GMT")) {
    const m = tzNamePart.value.match(/^GMT(?:(?<sign>[+-])(?<hh>\d{1,2})(?::?(?<mm>\d{2}))?)?$/);
    if (m && m.groups) {
      const sign = m.groups.sign || "+";
      const hh = String(m.groups.hh || "0").padStart(2, "0");
      const mm = String(m.groups.mm || "0").padStart(2, "0");
      offset = `${sign}${hh}:${mm}`;
    }
  }
  return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}:${parts.second}${offset}`;
}
function initEntityLists() {
  document.querySelectorAll('[data-filter="section"]').forEach((sec) => {
    const input = sec.querySelector('input[type="search"]');
    const list = sec.querySelector(".js-list");
    const count = sec.querySelector(".js-count");
    if (!input || !list || !count) return;
    const items = Array.from(list.querySelectorAll(".list-group-item"));
    const total = items.length;
    const update = () => {
      const q = (input.value || "").trim().toLowerCase();
      let visible = 0;
      items.forEach((li) => {
        const txt = (li.getAttribute("data-search") || li.textContent || "").toLowerCase();
        const show = !q || txt.includes(q);
        li.classList.toggle("d-none", !show);
        if (show) visible++;
      });
      count.textContent = `${visible}/${total}`;
    };
    sec.setAttribute("data-filter", "section");
    input.addEventListener("input", update);
    update();
  });
}
export {
  disableDnD,
  enableDnD,
  formatISOInTimeZone,
  generateTooltip,
  getSelectValues,
  initEntityLists,
  isPasswordRepeatValid,
  isPasswordValid,
  matchPassword,
  objectToArray,
  padNumber,
  post,
  refreshState,
  removeTooltip,
  setCurrentNavLocation,
  showInlineAlert,
  startInlineEdit,
  startInlineEditArea,
  validate,
  verifyPassword
};
//# sourceMappingURL=module_functions.gen.js.map
