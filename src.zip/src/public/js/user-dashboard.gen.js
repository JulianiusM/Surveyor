// src/public/js/user-dashboard.ts
import { initEntityLists, setCurrentNavLocation } from "./module_functions.gen.js";
function init() {
  setCurrentNavLocation();
  initEntityLists();
}
window.Surveyor.init = init;
export {
  init
};
//# sourceMappingURL=user-dashboard.gen.js.map
